from django.apps import AppConfig


class PlantedgeConfig(AppConfig):
    name = 'plantedge'
